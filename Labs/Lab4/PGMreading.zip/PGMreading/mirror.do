vlib work
vmap work work

vcom -93 Image_Process.vhd


vsim Image_Process 



-- run simulation
run 1 ns
