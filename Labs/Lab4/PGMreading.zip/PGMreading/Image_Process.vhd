-------------------------------------------------------
-- File:     Image_Process.vhd
--
-- Entity:	  Image_Process
-- Arch:     Mirror,Contrast,Filter
-- Created:  2/13/04
--
-- Description:  The following is an entity and 
--               an arch. description 3 image processing
--               algorithms (Mirror)
-------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_textio.all;
use std.textio.all;

entity Image_Process is
	generic(
		max_row : integer := 512;
		max_col : integer := 512);
end Image_Process;

architecture Mirror of Image_Process is

type timage is array( 1 to max_row, 1 to max_col ) of integer range 0 to 255;
file inFile : TEXT open READ_MODE is "boat.pgm";
file outFile : TEXT open WRITE_MODE is "boatOUT.pgm";

shared variable inimage, outimage : timage;
shared variable line1, line2, line3, line4 : line;
signal readdone, procdone : boolean := false;

begin
read1: process
	variable tempLine : line;
	variable pixel, row, col : integer;
	variable status : boolean;

begin
	--save header information
	readline( inFile, line1 );
	readline( inFile, line2 );
	readline( inFile, line3 );
	readline( inFile, line4 );

	row := 1;
	col := 1;
	
	--read rest of file
	while not endfile( inFile ) loop
		--get line
		readline( inFile, tempLine );
		status := true;
		while (status = true) loop     --checks for end of line
			--read pixels from line
			read( tempLine, pixel, status );
			if (status = true) then
				inimage(row,col) := pixel;
				if ( col = max_col ) then
					col := 1;
					row := row + 1;
				else
					col := col + 1;
				end if;
			end if;
		end loop;
	end loop;

	readdone <= true;
	wait;
end process;

image_proc1: process
begin
	wait until readdone = true;
	
	--flip of image
	for row in 1 to max_row loop
		for col in 1 to max_col loop
			
			--horizontally
			outimage(row,max_col-col+1) := inimage(row, col);
	
			--vertically
			--outimage( max_row-row+1, col ) := inimage(row, col );

		end loop;
	end loop;

	procdone <= true;
	wait;
end process;

writing1: process
variable lineout : line;

begin

	wait until procdone = true;

--rewrite header lines
writeline( outFile, line1 );
writeline( outFile, line2 );
writeline( outFile, line3 );
writeline( outFile, line4 );

for row in 1 to max_row loop
	for col in 1 to max_col loop

		write( lineout, outimage(row, col) );
		write( lineout, ' ' );
	
	end loop;

	writeline( outfile, lineout );
end loop;

wait;
end process;

end Mirror;

